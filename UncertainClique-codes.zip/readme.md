# Compile
  make
# Usage
  ./uclique [filepath] -a=1|2 -k=[0,n] -e=[0,1]
  "-a=" is the executed algorithm, where "-a=1" for pivot algorithm with topCore reduction and "-a=2" for pivot algorithm with topTriangle reduction.
  "-k=" is the minsize constraint.
  "-e=" is the clique probability constraint.
